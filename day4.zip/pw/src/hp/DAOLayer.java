package hp;

import java.util.ArrayList;
import java.util.List;

import basics.Emp;

public class DAOLayer {

	public Emp getDetailsFromDB(int empnoi) {
		// TODO Auto-generated method stub
		Emp e =null;
		int x = (int)(Math.random() * 10);
		System.out.println(x);
		if( x > 3)
		{
			e  =new Emp();
			e.setEmpno(empnoi);
			if(empnoi %  2 == 0)
			{
				e.setMn(4);
				e.setPin(5);
				
			}
			
			
		}
		return e;
	}

	public List<Emp> getMultipleDetailsFromDb(int pini) {
		// TODO Auto-generated method stub
		List<Emp> l =null;
		int x = (int)(Math.random() * 10);
		System.out.println(x);
		if( x > 3)
		{
				l =new ArrayList<Emp>();
				if(pini % 2 != 0)
				{
					l.add(new Emp(10,pini,90));
					l.add(new Emp(20,pini,80));
					l.add(new Emp(30,pini,70));
					
					
					
				}
			
			
	
	}
		return l;
	}

}
