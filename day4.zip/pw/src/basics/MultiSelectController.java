package basics;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import hp.EmpService;

public class MultiSelectController {

	public String getEmpDetailsOnPIncode(HttpServletRequest request) {
		// TODO Auto-generated method stub
		String pagename ="/WEB-INF/rm.html";
		System.out.println("poem writing will kill");
		
		String pin = request.getParameter("pin");
		int pini = Integer.parseInt(pin);
		
		EmpService e =new EmpService();
		List<Emp> l = e.getAllEmpBasedOnPinCode(pini) ;// same anthem
		if( l != null)
		{
			
			pagename ="/mulemp.jsp";
			if(l.size()> 0)
			{
				request.setAttribute("k1", "employees found in the pincode " + pini);
				request.setAttribute("k2", l);
				
				
			}
			else
			{
				
				request.setAttribute("k1", "employees not found in the pincode " + pini);
				
				
				
			}
			
			
		}
		
		
		
		return pagename;
	}

}
