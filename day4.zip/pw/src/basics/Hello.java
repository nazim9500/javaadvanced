package basics;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Hello
 */
@WebServlet("/Scrap")
public class Hello extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Hello() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, 
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, 
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String tellmeWhydidyoucomehere = request.getParameter("WHY");
		if(tellmeWhydidyoucomehere.equals("checkposorneg"))
		{
			X_Controller  t =new X_Controller();
			String responsepage = t.scrap(request);  // i am doing
			//function design, by myself, when will you do it.
			System.out.println("see this on server" + responsepage);
			RequestDispatcher rd = request.getRequestDispatcher(responsepage);
			rd.forward(request, response);
			
		}
		else if(tellmeWhydidyoucomehere.equals("oe"))
		{
			CIIID    s =new CIIID  ();
			String responsepage = s.checkoddorEven(request);  // i am doing
			//function design, by myself, when will you do it.
			System.out.println("see this on server" + responsepage);
			RequestDispatcher rd = request.getRequestDispatcher(responsepage);
			rd.forward(request, response);
			
		}
		else if(tellmeWhydidyoucomehere.equals("sdbcavynnb"))
		{
			Controller5 c =new Controller5();
			String responsepage = c.fifthMultiple(request);
			
			RequestDispatcher rd = request.getRequestDispatcher(responsepage);
			rd.forward(request, response);
			
			
			
		}
		
		else if(tellmeWhydidyoucomehere.equals("getDetails"))
		{
			
			EmpgetDetailsController x =new EmpgetDetailsController();
			String responsepage = x.getEmpDetails(request);
			
			RequestDispatcher rd = request.getRequestDispatcher(responsepage);
			rd.forward(request, response);
			
			
		}
		
		else if(tellmeWhydidyoucomehere.equals("getmultipledetails"))
		{
			
			MultiSelectController x =new MultiSelectController();
			String responsepage = x.getEmpDetailsOnPIncode(request);
			
			RequestDispatcher rd = request.getRequestDispatcher(responsepage);
			rd.forward(request, response);
			
			
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		//response.getWriter().println("post mode of request done in servlet");
	}

}
