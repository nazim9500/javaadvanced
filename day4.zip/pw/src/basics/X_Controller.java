package basics;

import javax.servlet.http.HttpServletRequest;

public class X_Controller {

	public String scrap(HttpServletRequest request) {
		// TODO Auto-generated method stub
		String pn ="neg.html";
		System.out.println("prove we reached till here");
		String y = request.getParameter("V1");
		int x = Integer.parseInt(y);
		if( x > 0)
			  pn ="pos.html";
		return pn;
	}

}
