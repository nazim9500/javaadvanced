package basics;

public class Emp {
	
	private int empno, pin,mn;

	public int getEmpno() {
		return empno;
	}

	public void setEmpno(int empno) {
		this.empno = empno;
	}

	public int getPin() {
		return pin;
	}

	public void setPin(int pin) {
		this.pin = pin;
	}

	public int getMn() {
		return mn;
	}

	public void setMn(int mn) {
		this.mn = mn;
	}

	public Emp() {
		// TODO Auto-generated constructor stub
	}

	public Emp(int empno, int pin, int mn) {
		
		this.empno = empno;
		this.pin = pin;
		this.mn = mn;
	}
	
	

}
