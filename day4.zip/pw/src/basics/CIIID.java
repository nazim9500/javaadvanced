package basics;

import javax.servlet.http.HttpServletRequest;

public class CIIID {

	public String checkoddorEven(HttpServletRequest request) {
		// TODO Auto-generated method stub
		String pn  ="/WEB-INF/e.html";
		String y = request.getParameter("num1");
		int x = Integer.parseInt(y);
		if( x % 2 != 0)
			 pn ="/WEB-INF/o.html";
		
		
		
		return pn;
	}

}
