package basics;

import javax.servlet.http.HttpServletRequest;

public class Controller5 {

	public String fifthMultiple(HttpServletRequest request) {
		// TODO Auto-generated method stub
		String pagename="/WEB-INF/basics.html";
		
		
		String z = request.getParameter("V1");
		
		int i = Integer.parseInt(z);
		if( i != 0)
		{
			int result = i *5;
			//issue is put result on the page and not here.
			//write the result to the notice board.how
			
			request.setAttribute("k1", result);  // those 
			//who dont know map will be in HELL.
			
			
			
			pagename="/WEB-INF/hello.jsp";
			
			
		}
		
		
		
		
		
		return pagename;
	}

}
