package basics;

import javax.servlet.http.HttpServletRequest;

import hp.EmpService;

public class EmpgetDetailsController {

	public String getEmpDetails(HttpServletRequest request) {
		// TODO Auto-generated method stub
		String pagename ="/WEB-INF/rm.html";
	
		String empno = request.getParameter("empno");
		int empnoi = Integer.parseInt(empno);
		
		
		EmpService s = new EmpService();
		
		// some old thing, function design is mine.
		Emp e  = s.getEmpDetails(empnoi); //requires intelligence
		if( e !=  null)
		{
				pagename="/emp.jsp";
				if(e.getMn() == 0)
				{
					request.setAttribute("k1", empno  + "not found");
					
					
				}
				else
				{
					request.setAttribute("k1",empno   +  " found");
					request.setAttribute("k2", e);
					
				}
				
				
				
			
		}
		
		
		
		System.out.println("controller reached");
		return pagename;
	}

}
